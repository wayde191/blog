#!/usr/bin/python
#-*-coding:utf-8-*-

from datetime import *

today = date.today()

print today